package com.rbp.movieapp.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;


@Service
public class MovieDeleteProducerService {
	
	@Autowired
	private KafkaTemplate<String, string> kafkaTemplate;
	
	
	@Value(value ="${kafka.topic.movie-delete}" )
	private String deleteTopic;
	
	public void sendDeleteMessage(String movieId) {
		kafkaTemplate.send(deleteTopic, movieId);
	}
}
